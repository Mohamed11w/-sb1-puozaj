import React, { useState, useEffect } from 'react';
import { Shield, Lock, Unlock, Copy, RefreshCw } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import toast from 'react-hot-toast';
import { encrypt, decrypt } from '../utils/crypto';
import { addSearch } from '../utils/db';
import { PasswordStrengthMeter } from '../components/PasswordStrengthMeter';

export function Encryption() {
  const location = useLocation();
  const [text, setText] = useState('');
  const [password, setPassword] = useState('');
  const [encryptedText, setEncryptedText] = useState('');
  const [isEncrypting, setIsEncrypting] = useState(false);
  const [isDecrypting, setIsDecrypting] = useState(false);

  useEffect(() => {
    if (location.state?.searchTerm) {
      setText(location.state.searchTerm);
    }
  }, [location.state]);

  const handleEncrypt = async () => {
    if (!text || !password) {
      toast.error('Please enter both text and password');
      return;
    }

    try {
      setIsEncrypting(true);
      const encrypted = await encrypt(text, password);
      setEncryptedText(encrypted);
      await addSearch(text, 'encryption', password);
      toast.success('Text encrypted successfully');
    } catch (error) {
      toast.error('Encryption failed');
    } finally {
      setIsEncrypting(false);
    }
  };

  const handleDecrypt = async () => {
    if (!encryptedText || !password) {
      toast.error('Please enter both encrypted text and password');
      return;
    }

    try {
      setIsDecrypting(true);
      const decrypted = await decrypt(encryptedText, password);
      setText(decrypted);
      await addSearch(decrypted, 'decryption', password);
      toast.success('Text decrypted successfully');
    } catch (error) {
      toast.error('Decryption failed. Please check your password.');
    } finally {
      setIsDecrypting(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="text-center mb-12">
        <Shield className="w-16 h-16 mx-auto mb-4 text-emerald-400" />
        <h1 className="text-4xl font-bold mb-2">Secure Encryption Tool</h1>
        <p className="text-gray-400">
          Military-grade encryption using AES-256-GCM with PBKDF2
        </p>
      </div>

      <div className="space-y-8">
        <div className="bg-gray-800 rounded-xl p-6 shadow-xl border border-gray-700">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Password</label>
              <div className="relative">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-gray-900 rounded-lg px-4 py-2 border border-gray-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition"
                  placeholder="Enter your secure password"
                />
              </div>
              <div className="mt-2">
                <PasswordStrengthMeter password={password} />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Text to Encrypt/Decrypt
              </label>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="w-full bg-gray-900 rounded-lg px-4 py-2 border border-gray-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition h-32"
                placeholder="Enter text to encrypt..."
              />
              <div className="mt-2 flex justify-end">
                <button
                  onClick={() => copyToClipboard(text)}
                  className="text-gray-400 hover:text-emerald-400 transition"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex gap-4">
              <button
                onClick={handleEncrypt}
                disabled={isEncrypting}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg px-4 py-2 flex items-center justify-center gap-2 transition disabled:opacity-50"
              >
                {isEncrypting ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Lock className="w-4 h-4" />
                )}
                Encrypt
              </button>
              <button
                onClick={handleDecrypt}
                disabled={isDecrypting}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-4 py-2 flex items-center justify-center gap-2 transition disabled:opacity-50"
              >
                {isDecrypting ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Unlock className="w-4 h-4" />
                )}
                Decrypt
              </button>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 shadow-xl border border-gray-700">
          <label className="block text-sm font-medium mb-2">Encrypted Text</label>
          <textarea
            value={encryptedText}
            onChange={(e) => setEncryptedText(e.target.value)}
            className="w-full bg-gray-900 rounded-lg px-4 py-2 border border-gray-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition h-32"
            placeholder="Enter encrypted text to decrypt..."
          />
          <div className="mt-2 flex justify-end">
            <button
              onClick={() => copyToClipboard(encryptedText)}
              className="text-gray-400 hover:text-emerald-400 transition"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="mt-8 text-center text-sm text-gray-500">
        <p>
          This tool uses AES-256-GCM encryption with PBKDF2 key derivation
          (600,000 iterations) and secure random IVs.
        </p>
        <p className="mt-2">
          All encryption/decryption is performed locally in your browser.
          No data is ever sent to any server.
        </p>
      </div>
    </div>
  );
}