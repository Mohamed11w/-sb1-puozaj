import React from 'react';
import { AuthSettings } from '../components/AuthSettings';

export function Settings() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <h1 className="text-3xl font-bold mb-8">Account Settings</h1>
      <div className="bg-gray-800 rounded-xl p-6 shadow-xl border border-gray-700">
        <AuthSettings />
      </div>
    </div>
  );
}