import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { encrypt, decrypt } from './crypto';

interface SearchHistoryDB extends DBSchema {
  searches: {
    key: string;
    value: {
      id: string;
      term: string; // Encrypted search term
      timestamp: number;
      type: 'encryption' | 'decryption';
    };
    indexes: { 'by-timestamp': number };
  };
}

const DB_NAME = 'secure-crypto-app';
const DB_VERSION = 1;

let db: IDBPDatabase<SearchHistoryDB>;

export async function initDB() {
  db = await openDB<SearchHistoryDB>(DB_NAME, DB_VERSION, {
    upgrade(db) {
      const store = db.createObjectStore('searches', {
        keyPath: 'id',
      });
      store.createIndex('by-timestamp', 'timestamp');
    },
  });
}

export async function addSearch(
  term: string,
  type: 'encryption' | 'decryption',
  password: string
) {
  if (!db) await initDB();
  
  try {
    const encryptedTerm = await encrypt(term, password);
    await db.add('searches', {
      id: crypto.randomUUID(),
      term: encryptedTerm,
      timestamp: Date.now(),
      type,
    });
  } catch (error) {
    console.error('Failed to save search:', error);
  }
}

export async function searchHistory(
  query: string,
  password: string
): Promise<Array<{ term: string; timestamp: number; type: string }>> {
  if (!db) await initDB();

  const allSearches = await db.getAll('searches');
  const results = [];

  for (const search of allSearches) {
    try {
      const decryptedTerm = await decrypt(search.term, password);
      if (decryptedTerm.toLowerCase().includes(query.toLowerCase())) {
        results.push({
          term: decryptedTerm,
          timestamp: search.timestamp,
          type: search.type,
        });
      }
    } catch (error) {
      // Skip entries that can't be decrypted with the current password
      continue;
    }
  }

  return results.sort((a, b) => b.timestamp - a.timestamp);
}