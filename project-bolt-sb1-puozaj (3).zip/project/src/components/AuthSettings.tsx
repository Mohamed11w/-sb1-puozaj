import React, { useState } from 'react';
import { Shield, Key, CreditCard } from 'lucide-react';

interface SecuritySetting {
  id: string;
  title: string;
  description: string;
  enabled: boolean;
}

export function AuthSettings() {
  const [securitySettings, setSecuritySettings] = useState<SecuritySetting[]>([
    {
      id: '2fa',
      title: 'Two-Factor Authentication',
      description: 'Add an extra layer of security to your account',
      enabled: false
    },
    {
      id: 'strong-password',
      title: 'Require Strong Password',
      description: 'Enforce minimum password strength requirements',
      enabled: true
    }
  ]);

  const toggleSetting = (id: string) => {
    setSecuritySettings(settings =>
      settings.map(setting =>
        setting.id === id
          ? { ...setting, enabled: !setting.enabled }
          : setting
      )
    );
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-700 pb-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5 text-emerald-400" />
          Security Settings
        </h2>
        <div className="space-y-4">
          {securitySettings.map(setting => (
            <div key={setting.id} className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">{setting.title}</h3>
                <p className="text-sm text-gray-400">{setting.description}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  className="sr-only peer"
                  checked={setting.enabled}
                  onChange={() => toggleSetting(setting.id)}
                />
                <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-800 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>
          ))}
        </div>
      </div>

      <div className="border-b border-gray-700 pb-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <Key className="w-5 h-5 text-emerald-400" />
          Password Requirements
        </h2>
        <div className="space-y-2 text-sm text-gray-400">
          <p>• Minimum 12 characters</p>
          <p>• At least one uppercase letter</p>
          <p>• At least one number</p>
          <p>• At least one special character</p>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-emerald-400" />
          Payment Methods
        </h2>
        <button
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg px-4 py-2 transition"
          onClick={() => {/* Implement payment method addition */}}
        >
          Add Payment Method
        </button>
      </div>
    </div>
  );
}