import React from 'react';
import { Clock, Lock, Unlock } from 'lucide-react';

interface SearchResult {
  term: string;
  timestamp: number;
  type: string;
}

interface SearchResultsProps {
  results: SearchResult[];
  onSelect: (term: string) => void;
}

export function SearchResults({ results, onSelect }: SearchResultsProps) {
  if (results.length === 0) {
    return null;
  }

  return (
    <div className="absolute top-full left-0 right-0 mt-2 bg-gray-800 rounded-lg border border-gray-700 shadow-lg overflow-hidden max-h-96 overflow-y-auto">
      {results.map((result, index) => (
        <button
          key={`${result.timestamp}-${index}`}
          onClick={() => onSelect(result.term)}
          className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-700 transition text-left border-b border-gray-700 last:border-0"
        >
          {result.type === 'encryption' ? (
            <Lock className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          ) : (
            <Unlock className="w-4 h-4 text-blue-400 flex-shrink-0" />
          )}
          <div className="flex-1 min-w-0">
            <p className="text-sm text-white truncate">{result.term}</p>
            <p className="text-xs text-gray-400 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {new Date(result.timestamp).toLocaleString()}
            </p>
          </div>
        </button>
      ))}
    </div>
  );
}