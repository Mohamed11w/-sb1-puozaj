import React from 'react';
import zxcvbn from 'zxcvbn';

interface PasswordStrengthMeterProps {
  password: string;
}

export function PasswordStrengthMeter({ password }: PasswordStrengthMeterProps) {
  const result = zxcvbn(password);
  const strengthScore = result.score;

  const getStrengthColor = () => {
    switch (strengthScore) {
      case 0: return 'bg-red-500';
      case 1: return 'bg-orange-500';
      case 2: return 'bg-yellow-500';
      case 3: return 'bg-lime-500';
      case 4: return 'bg-green-500';
      default: return 'bg-gray-200';
    }
  };

  const getStrengthText = () => {
    switch (strengthScore) {
      case 0: return 'Very Weak';
      case 1: return 'Weak';
      case 2: return 'Fair';
      case 3: return 'Strong';
      case 4: return 'Very Strong';
      default: return 'No Password';
    }
  };

  return (
    <div className="w-full space-y-1">
      <div className="flex h-2 overflow-hidden rounded-full bg-gray-200">
        {[...Array(5)].map((_, index) => (
          <div
            key={index}
            className={`flex-1 ${index <= strengthScore ? getStrengthColor() : ''}`}
          />
        ))}
      </div>
      <p className="text-sm text-gray-600">
        Password Strength: <span className="font-medium">{getStrengthText()}</span>
      </p>
      {result.feedback.warning && (
        <p className="text-sm text-red-500">{result.feedback.warning}</p>
      )}
    </div>
  );
}