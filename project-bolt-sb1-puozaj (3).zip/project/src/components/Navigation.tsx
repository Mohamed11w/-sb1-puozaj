import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Search, X } from 'lucide-react';
import { searchHistory } from '../utils/db';
import { SearchResults } from './SearchResults';
import toast from 'react-hot-toast';

export function Navigation() {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [password, setPassword] = useState('');
  const [showPasswordInput, setShowPasswordInput] = useState(false);

  const showBackButton = location.pathname !== '/';

  useEffect(() => {
    if (searchQuery && password) {
      const delayDebounceFn = setTimeout(async () => {
        try {
          setIsSearching(true);
          const results = await searchHistory(searchQuery, password);
          setSearchResults(results);
        } catch (error) {
          console.error('Search failed:', error);
          toast.error('Failed to search history. Check your password.');
        } finally {
          setIsSearching(false);
        }
      }, 300);

      return () => clearTimeout(delayDebounceFn);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery, password]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery) return;

    if (!password) {
      setShowPasswordInput(true);
      return;
    }
  };

  const handleSearchSelect = (term: string) => {
    setSearchQuery('');
    setSearchResults([]);
    navigate('/', { state: { searchTerm: term } });
  };

  return (
    <div className="bg-gray-800 border-b border-gray-700 py-4">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          {showBackButton && (
            <button
              onClick={() => navigate(-1)}
              className="text-gray-400 hover:text-white transition"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
          )}
        </div>
        
        <form onSubmit={handleSearch} className="flex-1 max-w-md mx-4">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search encrypted history..."
              className="w-full bg-gray-900 rounded-lg pl-10 pr-4 py-2 border border-gray-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition text-white"
            />
            <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 ${isSearching ? 'animate-spin' : ''}`} />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            {showPasswordInput && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-gray-800 rounded-lg border border-gray-700 p-4 shadow-lg">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password to search"
                  className="w-full bg-gray-900 rounded-lg px-4 py-2 border border-gray-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition text-white mb-2"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowPasswordInput(false)}
                    className="px-3 py-1 text-sm text-gray-400 hover:text-white transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1 text-sm bg-emerald-600 hover:bg-emerald-700 text-white rounded transition"
                  >
                    Search
                  </button>
                </div>
              </div>
            )}
            <SearchResults results={searchResults} onSelect={handleSearchSelect} />
          </div>
        </form>

        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/settings')}
            className="text-gray-200 hover:text-white transition px-4 py-2 rounded-lg hover:bg-gray-700"
          >
            Settings
          </button>
        </div>
      </div>
    </div>
  );
}